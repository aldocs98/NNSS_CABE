from datetime import datetime
from utils.kmh_func import km_hectometro
from kivymd.toast import toast
import sqlite3

def calcular_hueco(ancho,largo):
    
    hueco_calculado=float(ancho)*float(largo)
    
    return hueco_calculado
    
def ingresar_huecos(root,Huecos, session):
    
    #data ingresada
    
    fecha_h=datetime.today()
    pk_h=""
    ancho_h=0.0
    largo_h=0.0
    altura_h=0.0
    obs_h=""
    carril_h=root.root.ids.carril_h.text
    elemento_h=root.root.ids.elemento_h.text
    km_h, hectometro_h = 0.0,0.0
    hueco_h=0.0
    
    #defecto
    defecto_h=""

    lat=0.0
    lon=0.0

    #sqlite
    i_registro = Huecos(Elemento=elemento_h,PK_Inicial=pk_h,Latitud=float(lat),Longitud=float(lon),Carril =carril_h,\
                        Ancho=ancho_h,Largo=largo_h,Altura=altura_h,Hueco=hueco_h,\
                            Observaciones=obs_h,KM=km_h,HM=hectometro_h,\
                                Defecto=defecto_h,Fecha_Obs=fecha_h)
    
    session.add(i_registro)
    
    #commit
    session.commit() # ejecuta los cambios y cargalos a la base de datos real
    root.root.ids.Ingresando_Valores_huecos.text="Datos Ingresados"
    root.root.ids.id_elemento.text="HUE_"+str(i_registro.id)
    root.root.ids.huecos_label.text=str(i_registro.id)
    toast("Se creó: "+"HUE_"+str(i_registro.id))

def actualizar_huecos(root, ubi):

    id_elemento = root.root.ids.huecos_label.text
    
    if id_elemento=="N":
        toast("NO HA CREADO ELEMENTO")
    else:
        # Data ingresada
        fecha_h = datetime.today()
        pk_h = root.root.ids.pki_huecos.text
        ancho_h = root.root.ids.ancho_huecos.text
        largo_h = root.root.ids.largo_huecos.text
        altura_h = root.root.ids.altura_huecos.text
        obs_h = root.root.ids.observacion_huecos.text
        carril_h = root.root.ids.carril_h.text
        elemento_h = root.root.ids.elemento_h.text
        km_h, hectometro_h = km_hectometro(pk_h)
        hueco_h = calcular_hueco(ancho_h, largo_h)

        # Defecto
        defecto_h = "SI"

        lat = root.root.ids.lat_label.text
        lon = root.root.ids.lon_label.text

        # Conectarse a la base de datos
        connection = sqlite3.connect(ubi)
        cursor = connection.cursor()

        # Ejecutar consulta UPDATE para actualizar el registro en la base de datos
        cursor.execute('''UPDATE Registro_Huecos SET Elemento=?, PK_Inicial=?, Latitud=?, Longitud=?, Carril=?, Ancho=?, Largo=?, Altura=?, Hueco=?, Observaciones=?, KM=?, HM=?, Defecto=?, Fecha_Obs=? WHERE id=?''', 
                    (elemento_h, pk_h, float(lat), float(lon), carril_h, ancho_h, largo_h, altura_h, hueco_h, obs_h, km_h, hectometro_h, defecto_h, fecha_h, int(id_elemento)))

        # Guardar cambios en la base de datos
        connection.commit()

        # Cerrar la conexión con la base de datos
        connection.close()

        root.root.ids.Ingresando_Valores_huecos.text = "Datos Actualizados"
        root.root.ids.id_elemento.text = "HUE_" + str(id_elemento)
        root.root.ids.huecos_label.text="N"
        toast("Se actualizó: "+"HUE_"+str(id_elemento))

def limpiar_huecos(root):
    
    root.root.ids.Ingresando_Valores_huecos.text="Ingresando Datos..."
    
    root.root.ids.pki_huecos.text=""

    root.root.ids.ancho_huecos.text=""

    root.root.ids.largo_huecos.text=""

    root.root.ids.altura_huecos.text=""
    
    root.root.ids.observacion_huecos.text=""
