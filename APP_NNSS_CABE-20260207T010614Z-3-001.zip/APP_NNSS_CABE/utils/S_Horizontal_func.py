from datetime import datetime
import sqlite3
from kivymd.uix.menu import MDDropdownMenu

def menu_progresivas(root):

    subtramo=root.root.ids.ruta_label.text
    km_text=root.root.ids.km_SH.text

    try:
        pro_nombre_db="BD_Señalización_Horizontal"
        con = sqlite3.connect(pro_nombre_db+".db")
        cursor = con.cursor()
        consulta_valor='SELECT PROG_INICIAL FROM '+pro_nombre_db +" WHERE (RUTA=?) AND (KM=?)"
        cursor.execute(consulta_valor,[subtramo,km_text])

    except:
        print("Error")

    resultados = cursor.fetchall()

    lista_progresivas=[]
    for resultado in resultados:
        lista_progresivas.append(resultado[0])

    #CONVERSIÓN A STRING
    l_progresivas=[str(LP) for LP in lista_progresivas]
        
    menu_km_progresiva = [
        {
            "text": a_i,
            "font_size":60,
            "viewclass": "OneLineListItem",
            "on_release": lambda x=a_i: valor_progresivas(root,x),
        } for a_i in l_progresivas
    ]
    root.menu = MDDropdownMenu(
        caller=root.screen.ids.prog_SH,
        items=menu_km_progresiva,
        width_mult=4,
    )

def valor_progresivas(root,text_item):

    progresiva_text=text_item
    root.root.ids.prog_SH.text=progresiva_text

    subtramo=root.root.ids.ruta_label.text
    km_text=root.root.ids.km_SH.text

    pro_nombre_db="BD_Señalización_Horizontal"
    con = sqlite3.connect(pro_nombre_db+".db")
    cursor = con.cursor()
    consulta_valor="SELECT *FROM BD_Señalización_Horizontal WHERE (RUTA = ?) AND (KM = ?) AND (PROG_INICIAL = ?)"
    cursor.execute(consulta_valor,[subtramo,km_text,progresiva_text])
        
    #índice de columnas
    data_elemento=cursor.fetchall()
    LISTA_ELEMENTO_PROGRESIVA=data_elemento[0]

    id_SH=str(LISTA_ELEMENTO_PROGRESIVA[0])
    root.root.ids.Prog_inicial_SH.text=str(LISTA_ELEMENTO_PROGRESIVA[3])
    root.root.ids.Prog_final_SH.text=str(LISTA_ELEMENTO_PROGRESIVA[6])
    root.root.ids.Estado_Conservacion_SH.text=str(LISTA_ELEMENTO_PROGRESIVA[24])
    root.root.ids.Estado_Uso_SH.text=str(LISTA_ELEMENTO_PROGRESIVA[25])
    root.root.ids.T_Izquierdo_SH.text=str(LISTA_ELEMENTO_PROGRESIVA[26])
    root.root.ids.T_Derecho_SH.text=str(LISTA_ELEMENTO_PROGRESIVA[27])
    root.root.ids.T_C_Continuo_SH.text=str(LISTA_ELEMENTO_PROGRESIVA[28])
    root.root.ids.T_C_Discontinuo_SH.text=str(LISTA_ELEMENTO_PROGRESIVA[29])

    con.commit()
    con.close()

    root.menu.dismiss()

    root.root.ids.SH_Inv_label.text=id_SH

def actualizar_SH_inv(root):

    id_SH=root.root.ids.SH_Inv_label.text

    pro_nombre_db="BD_Señalización_Horizontal"
    con = sqlite3.connect(pro_nombre_db+".db")
    cursor = con.cursor()

    prog_inicial=root.root.ids.Prog_inicial_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET PROG_INICIAL = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[float(prog_inicial),id_SH])

    prog_final=root.root.ids.Prog_final_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET PROG_FINAL = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[float(prog_final),id_SH])

    estado_conservacion=root.root.ids.Estado_Conservacion_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET ESTADO_DE_CONSERVACION = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[estado_conservacion,id_SH])

    estado_uso=root.root.ids.Estado_Uso_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET ESTADO_DE_USO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[estado_uso,id_SH])

    t_izquierdo=root.root.ids.T_Izquierdo_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET TACHAS_IZQUIERDO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[int(t_izquierdo),id_SH])

    t_derecho=root.root.ids.T_Derecho_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET TACHAS_DERECHO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[int(t_derecho),id_SH])

    t_c_continuo=root.root.ids.T_C_Continuo_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET TACHAS_CENTRO_CONTINUO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[int(t_c_continuo),id_SH])

    t_c_discontinuo=root.root.ids.T_C_Discontinuo_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET TACHAS_CENTRO_DISCONTINUO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[int(t_c_discontinuo),id_SH])

    con.commit()
    con.close()

    root.root.ids.id_elemento.text="09SH_"+id_SH

def añadir_SH_inv(root):

    fecha_inv=datetime.today()

    pro_nombre_db="BD_Señalización_Horizontal"
    con = sqlite3.connect(pro_nombre_db+".db")
    cursor = con.cursor()

    # Ejecutar la sentencia SQL para seleccionar los valores de la columna "mi_columna"
    cursor.execute("SELECT _id FROM "+pro_nombre_db)

    # Obtener los resultados de la consulta
    resultados = cursor.fetchall()

    # Pasar los valores a una lista
    valores_columna = [int(resultado[0]) for resultado in resultados]

    id_SH=str(max(valores_columna)+1)
    actualizacion_valor="INSERT INTO BD_Señalización_Horizontal (_id) VALUES (?)"
    cursor.execute(actualizacion_valor,[id_SH])

    subt=root.root.ids.ruta_label.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET RUTA = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[subt,id_SH])

    tramo=2
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET TRAMO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[tramo,id_SH])

    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET FECHA_DE_ALTA = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[fecha_inv,id_SH])

    periodo_nnss="2023-II"
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET PERIODO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[periodo_nnss,id_SH])

    prog_inicial=root.root.ids.Prog_inicial_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET PROG_INICIAL = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[float(prog_inicial),id_SH])

    prog_final=root.root.ids.Prog_final_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET PROG_FINAL = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[float(prog_final),id_SH])

    estado_conservacion=root.root.ids.Estado_Conservacion_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET ESTADO_DE_CONSERVACION = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[estado_conservacion,id_SH])

    estado_uso=root.root.ids.Estado_Uso_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET ESTADO_DE_USO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[estado_uso,id_SH])

    t_izquierdo=root.root.ids.T_Izquierdo_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET TACHAS_IZQUIERDO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[int(t_izquierdo),id_SH])

    t_derecho=root.root.ids.T_Derecho_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET TACHAS_DERECHO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[int(t_derecho),id_SH])

    t_c_continuo=root.root.ids.T_C_Continuo_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET TACHAS_CENTRO_CONTINUO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[int(t_c_continuo),id_SH])

    t_c_discontinuo=root.root.ids.T_C_Discontinuo_SH.text
    actualizacion_valor="UPDATE BD_Señalización_Horizontal SET TACHAS_CENTRO_DISCONTINUO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[int(t_c_discontinuo),id_SH])

    con.commit()
    con.close()

    root.root.ids.id_elemento.text="09SH_"+id_SH