def km_hectometro(pk):
    
    km=int(divmod(float(pk),1000)[0])

    dec_k=divmod(divmod(float(pk),1000)[1],100)[0]

    hectometro=int(dec_k)+1

    return km, hectometro