from datetime import datetime
import sqlite3
from kivymd.toast import toast

def ingresar_ahuellamiento(root,Ahuellamiento, session):

    #sqlite
    i_registro = Ahuellamiento(Elemento="Calzada", PK_Inicial=0, PK_Final=0,\
                        Longitud=0,Carril_I='Izquierdo', CI_H_Izquierda=0, CI_H_Derecha=0, CI_Observaciones="",\
                        Carril_D="Derecho", CD_H_Izquierda=0, CD_H_Derecha=0, CD_Observaciones="",\
                            KM=0, HM=0, Defecto="", Fecha_Obs=datetime.today())
    session.add(i_registro)

    #commit
    session.commit() # ejecuta los cambios y cargalos a la base de datos real
    toast("DATOS INGRESADOS")
    root.root.ids.plus_ahu.md_bg_color = [1, 0, 0, 1]
    root.root.ids.ahue_izquierdo.md_bg_color = [1, 0, 0, 1]
    root.root.ids.ahue_derecho.md_bg_color = [1, 0, 0, 1]
    root.root.ids.ahue_label.text=str(i_registro.id)
    toast("Se creó: "+"AHU_"+str(i_registro.id))

def actualizar_ahuellamiento(root, ubi):

    id_elemento = root.root.ids.ahue_label.text

    def defecto_ahuellamiento(ahuellamiento):
        if int(ahuellamiento)>11:
            
            defecto_ahue="SI"
        else:
            defecto_ahue="NO"
        
        return defecto_ahue

    if id_elemento=="N":
        toast("NO HA CREADO ELEMENTO")
    else:
        # Datos ingresados
        fecha_ahue = datetime.today()
        pki_ahue_I = int(float(root.root.ids.progresiva_ahuellamiento.text))
        kilometro_ahue = divmod(pki_ahue_I, 1000)[0]
        hectometro_sd = divmod(pki_ahue_I, 1000)[1]
        hectometro_ahue = divmod(hectometro_sd, 100)[0] + 1
        elemen = "Calzada"
        l_ahue = root.root.ids.longitud_ahuellamiento.text
        if l_ahue=="":
            l_ahue="100"
        pkf_ahue_F = int(pki_ahue_I) + int(l_ahue)
        
        # CARRIL IZQUIERDO
        A_i_i = root.root.ids.ahue_i_i.text or "0"
        A_d_i = root.root.ids.ahue_d_i.text or "0"
        obs_i = root.root.ids.obs_ahue_i.text  # Observaciones no necesitan conversión

        # CARRIL DERECHO
        A_i_d = root.root.ids.ahue_i_d.text or "0"
        A_d_d = root.root.ids.ahue_d_d.text or "0"
        obs_d = root.root.ids.obs_ahue_d.text  # Observaciones no necesitan conversión

        # Defecto
        defecto_ahue = defecto_ahuellamiento(max(int(A_i_i), int(A_d_i), int(A_i_d), int(A_d_d)))

        #Ingreso Base de Datos
        Actualizar_BD_AHU(root,ubi,elemen,pki_ahue_I,pkf_ahue_F,l_ahue,\
                          A_i_i,A_d_i,obs_i,\
                          A_i_d,A_d_d,obs_d,\
                            kilometro_ahue, hectometro_ahue, defecto_ahue,\
                            fecha_ahue,str(int(id_elemento)-1))

        # Actualizar etiquetas o widgets según sea necesario
        toast("DATOS ACTUALIZADOS")
        root.root.ids.plus_ahu.md_bg_color = [1, 1, 0, 1]
        toast("Se actualizó: "+"AHU_"+str(id_elemento))

        toast("INGRESANDO DATOS...")

def limpiar_ahuellamiento(root):

    toast("INGRESANDO DATOS...")
    #CARRIL IZQUIERDO
    root.root.ids.ahue_i_i.text=""
    root.root.ids.ahue_d_i.text=""
    root.root.ids.obs_ahue_i.text=""

    #CARRIL DERECHO
    root.root.ids.ahue_i_d.text=""
    root.root.ids.ahue_d_d.text=""
    root.root.ids.obs_ahue_d.text=""

    root.root.ids.longitud_ahuellamiento.text=""

def Actualizar_BD_AHU(root,ubi,elemen,pki_ahue_I,pkf_ahue_F,l_ahue,\
                          A_i_i,A_d_i,obs_i,\
                          A_i_d,A_d_d,obs_d,\
                            kilometro_ahue, hectometro_ahue, defecto_ahue,\
                            fecha_ahue,id_elemento):

        # Conectarse a la base de datos
        connection = sqlite3.connect(ubi)
        cursor = connection.cursor()

        # Ejecutar consulta UPDATE para actualizar el registro en la base de datos
        cursor.execute('''UPDATE Registro_Ahuellamiento SET Elemento=?, PK_Inicial=?, PK_Final=?,\
                        Longitud=?,Carril_I=?, CI_H_Izquierda=?, CI_H_Derecha=?, CI_Observaciones=?,\
                        Carril_D=?, CD_H_Izquierda=?, CD_H_Derecha=?, CD_Observaciones=?,\
                            KM=?, HM=?, Defecto=?, Fecha_Obs=? WHERE id=?''', 
                    (elemen, int(pki_ahue_I), int(pkf_ahue_F), int(l_ahue), "Izquierdo", int(A_i_i),\
                     int(A_d_i), obs_i, "Derecho", int(A_i_d), int(A_d_d), obs_d, \
                        int(kilometro_ahue), int(hectometro_ahue), defecto_ahue, fecha_ahue,\
                        int(id_elemento)))

        # Guardar cambios en la base de datos
        connection.commit()

        # Cerrar la conexión con la base de datos
        connection.close()
        root.root.ids.plus_ahu.md_bg_color = [0, 1, 0, 1]