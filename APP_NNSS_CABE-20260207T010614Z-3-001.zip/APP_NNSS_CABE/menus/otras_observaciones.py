from kivymd.uix.menu import MDDropdownMenu
from kivy.utils import get_color_from_hex

def otras_obs(root):
    obs_items = ['Obstaculos','Parches','Peladuras','Msuelto','Pcocodrilos']
    menu_obs_items = [
        {
            "text": obs_i,
            "font_size":60,
            "viewclass": "OneLineListItem",
            "text_color": get_color_from_hex("#FFFFFF"),
            "on_release": lambda x=obs_i: observaciones_valor(root,x),
        } for obs_i in obs_items
    ]

    root.menu = MDDropdownMenu(
        caller=root.screen.ids.otras_o,
        background_color=get_color_from_hex("#000000"),
        items=menu_obs_items,
        width_mult=4)
    
def observaciones_valor(root, text_item):
    
    otras_observaciones=text_item
    root.root.ids.otras_o.text=otras_observaciones
    root.menu.dismiss()




