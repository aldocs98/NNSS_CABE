from kivymd.uix.menu import MDDropdownMenu
from kivymd.toast import toast
from kivy.utils import get_color_from_hex
def menu_rutas(root):
    l_rutas=['PE-22','PE-3S','PE-3N']
    menu_l_rutas = [
        {
            "text": t_i,
            "font_size":60,
            "viewclass": "OneLineListItem",
            "text_color": get_color_from_hex("#FFFFFF"),
            "on_release": lambda x=t_i: valor_rutas(root,x),
        } for t_i in l_rutas
    ]
    
    root.menu = MDDropdownMenu(
        caller=root.screen.ids.ruta_label,
        items=menu_l_rutas,
        background_color=get_color_from_hex("#000000"),
        width_mult=3,
    )
    
def valor_rutas(root, text_item):

    subtramo=text_item
    root.root.ids.ruta_label.text=subtramo
    toast("SE ELIGIÓ LA RUTA:"+subtramo)
    root.menu.dismiss()
    