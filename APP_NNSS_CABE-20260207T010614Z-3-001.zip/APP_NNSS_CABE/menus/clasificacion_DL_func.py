from kivymd.uix.menu import MDDropdownMenu
from kivy.utils import get_color_from_hex

def menu_clasificacion_dl(root):
    carril_items = ['Cuneta','Zanja de drenaje','Cuneta de Coronación','Canal','Berma-Cuneta']
    
    menu_carril_items = [
        {
            "text": c_i,
            "font_size":60,
            "viewclass": "OneLineListItem",
            "text_color": get_color_from_hex("#FFFFFF"),
            "on_release": lambda x=c_i: carril_valor(root,x),
        } for c_i in carril_items
    ]

    root.menu = MDDropdownMenu(
        caller=root.screen.ids.clasificacion_DL,
        background_color=get_color_from_hex("#000000"),
        items=menu_carril_items,
        width_mult=4)
     
def carril_valor(root, text_item):
    
    carril=text_item
    root.root.ids.clasificacion_DL.text=carril
    root.menu.dismiss()