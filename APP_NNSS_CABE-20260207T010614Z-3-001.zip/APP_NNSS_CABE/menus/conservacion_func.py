from kivymd.uix.menu import MDDropdownMenu
from kivy.utils import get_color_from_hex

def menu_E_C(root):
    
    E_C_items = ['Bueno','Regular','Malo']
    menu_ec_items = [
        {
            "text": ec_i,
            "font_size":60,
            "viewclass": "OneLineListItem",
            "text_color": get_color_from_hex("#FFFFFF"),
            "on_release": lambda x=ec_i: E_C_valor(root,x),
        } for ec_i in E_C_items
    ]
    
    root.menu = MDDropdownMenu(
        caller=root.screen.ids.Estado_Conservacion_SH,
        background_color=get_color_from_hex("#000000"),
        items=menu_ec_items,
        width_mult=4)

def E_C_valor(root,text_item):
    
    ec=text_item
    root.root.ids.Estado_Conservacion_SH.text=ec
    root.menu.dismiss()