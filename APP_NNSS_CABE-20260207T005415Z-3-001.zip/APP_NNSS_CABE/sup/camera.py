# from kivy.lang import Builder
# from kivymd.uix.boxlayout import MDBoxLayout
# from kivymd.app import MDApp
# from kivy.uix.camera import Camera
# from kivymd.uix.dialog import MDDialog
# from kivy.core.window import Window
# from kivymd.uix.button import MDRaisedButton
# from kivymd.uix.toolbar import MDTopAppBar
# import time

# from kivy.metrics import sp,dp
# from kivy.uix.anchorlayout import AnchorLayout
# from kivy.properties import ObjectProperty, StringProperty, ListProperty,DictProperty
# from kivy.utils import platform
# from kivy.graphics.texture import Texture
# from kivy.config import Config


# # Window.size = (360, 640)  # Para emular el tamaño de un dispositivo móvil

# KV = '''
# MDBoxLayout:
#     orientation: 'vertical'

#     MDTopAppBar:
#         title: 'Cámara App'
#         md_bg_color: app.theme_cls.primary_color


#     Camera:
#         id: camera
#         resolution: (2560, 1440)
#         pos_hint: {"center_x":0.5,"center_y":0.5}

#         adaptive_height:True
#         play: True

#     MDBoxLayout:
#         size_hint_y: None
#         height: self.minimum_height
#         padding: dp(10)

#         MDRaisedButton:
#             text: 'Activar Cámara'
#             on_release: app.toggle_camera()

#         MDRaisedButton:
#             text: 'Capturar Foto'
#             on_release: app.capture_photo()
# '''

# class CameraApp(MDApp):
#     rotation_angle = 0
#     def __init__(self, **kwargs):
#         super().__init__(**kwargs)
#         self._request_android_permissions()

#     @staticmethod
#     def is_android():
#         return platform == 'android'

#     def _request_android_permissions(self):
#         """
#         Requests CAMERA permission on Android.
#         """
#         if not self.is_android():
#             return
        
#     def build(self):
#         self.theme_cls.primary_palette = "Blue"
#         return Builder.load_string(KV)
    
#     def toggle_camera(self):
#         camera = self.root.ids.camera
#         camera.play = not camera.play  # Activa o desactiva la cámara

#     def capture_photo(self):
#         camera = self.root.ids.camera
#         timestr = time.strftime("%Y%m%d_%H%M%S")
#         if camera.play:
#             camera.export_to_png("captura"+"_{}.png".format(timestr))  # Captura la imagen
#             print("Foto capturada y guardada")
#         else:
#             print("La cámara no está activa.")

# if __name__ == '__main__':
#     CameraApp().run()