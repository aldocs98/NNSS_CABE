from kivymd.uix.menu import MDDropdownMenu
from kivy.utils import get_color_from_hex

def menu_E_U(root):
    
    E_U_items = ['En Uso','En Desuso']
    menu_eu_items = [
        {
            "text": eu_i,
            "font_size":60,
            "viewclass": "OneLineListItem",
            "text_color": get_color_from_hex("#FFFFFF"),
            "on_release": lambda x=eu_i: E_U_valor(root,x),
        } for eu_i in E_U_items
    ]
    
    root.menu = MDDropdownMenu(
        caller=root.screen.ids.Estado_Uso_SH,
        background_color=get_color_from_hex("#000000"),
        items=menu_eu_items,
        width_mult=4)

def E_U_valor(root,text_item):
    
    eu=text_item
    root.root.ids.Estado_Uso_SH.text=eu
    root.menu.dismiss()