from kivymd.uix.menu import MDDropdownMenu
from kivy.utils import get_color_from_hex

def menu_elemento(root, caller):
    carril_items = ['Calzada', 'Berma']
    
    def set_value_and_close(menu, text):
        caller.text = text  # Asigna el valor seleccionado al botón correcto
        menu.dismiss()  # Cierra el menú

    elemento_items = [
        {
            "text": c_i,
            "font_size": 60,
            "viewclass": "OneLineListItem",
            "text_color": get_color_from_hex("#FFFFFF"),
            "on_release": lambda x=c_i: set_value_and_close(menu, x),  # Cierra al seleccionar
        }
        for c_i in carril_items
    ]

    menu = MDDropdownMenu(
        caller=caller,
        background_color=get_color_from_hex("#000000"),
        items=elemento_items,
        width_mult=4
    )
    
    menu.open()
    
def elemento_valor(root, text_item, caller):
    caller.text = text_item  # Se asigna el texto seleccionado al botón correcto
    root.menu.dismiss()