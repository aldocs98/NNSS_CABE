from kivymd.uix.menu import MDDropdownMenu
from kivy.utils import get_color_from_hex

def menu_observaciones(root):
    observacion_items = ['Complejo','Longitudinal','Transversal']
    menu_observacion_items = [
        {
            "text": o_i,
            "viewclass": "OneLineListItem",
            "font_size":60,
            "text_color": get_color_from_hex("#FFFFFF"),
            "on_release": lambda x=o_i: observaciones_valor(root,x),
        } for o_i in observacion_items
    ]
    root.menu = MDDropdownMenu(
        caller=root.screen.ids.obs,
        items=menu_observacion_items,
        background_color=get_color_from_hex("#000000"),
        width_mult=4)
    
def observaciones_valor(root, text_item):
    obs=text_item
    root.root.ids.obs.text=obs
    root.menu.dismiss()