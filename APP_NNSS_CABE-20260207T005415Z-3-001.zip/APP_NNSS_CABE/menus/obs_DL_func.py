from kivymd.uix.list import IRightBodyTouch, OneLineAvatarIconListItem
from kivymd.uix.selectioncontrol import MDCheckbox
from kivy.properties import StringProperty

class ListItemWithCheckbox_DL(OneLineAvatarIconListItem):
    '''Custom list item.'''
    icon = StringProperty("android")

class RightCheckbox_DL(IRightBodyTouch, MDCheckbox):
    '''Custom right container.'''

def on_start_DL(root):
    obsDL_items = ['Obstrucción al libre escurrimiento', 'Falla Estructural']
    for ea in obsDL_items:
        root.root.ids.scroll_dl.add_widget(
            ListItemWithCheckbox_DL(text=f"{ea}")
        )

def get_selected_DL(root):
    selected_items = []
    for item in root.root.ids.scroll_dl.children:
        if isinstance(item, ListItemWithCheckbox_DL):
            if item.ids.checkbox.active:
                selected_items.append(item.text)
    print("Selected items:", selected_items)

    root.root.ids.Observaciones_DL.text=",".join(selected_items)
    root.root.ids.screen_manager.current = 'scr 12'

    for item in root.root.ids.scroll_dl.children:
        if isinstance(item, ListItemWithCheckbox_DL):
            item.ids.checkbox.active = False