from kivymd.uix.menu import MDDropdownMenu
from kivy.utils import get_color_from_hex

def menu_km(root):

    ruta_escogida=root.root.ids.ruta_label.text
    if ruta_escogida=="PE-22":
        KM_items = ['38','48','56','68','69','92','106','112','121','132','146','152','169','170']
    
    elif ruta_escogida=="PE-3S":
        KM_items = ['0', '9', '18', '19', '29', '39', '45', '49', '70', '80', '90', '101']

    elif ruta_escogida=="PE-3N":
        KM_items = ['1','10','20','32','40','50','56','66','67','83','91','104','113']

    menu_KM_items = [
        {
            "text": km_i,
            "font_size":60,
            "viewclass": "OneLineListItem",
            "text_color": get_color_from_hex("#FFFFFF"),
            "on_release": lambda x=km_i: km_valor(root,x),
        } for km_i in KM_items
    ]
    root.menu = MDDropdownMenu(
        caller=root.screen.ids.km_bd,
        background_color=get_color_from_hex("#000000"),
        items=menu_KM_items,
        width_mult=4)

def km_valor(root, text_item):
    
    elemento=text_item
    root.root.ids.km_bd.text=elemento
    root.root.ids.km_inv.text=elemento
    root.root.ids.km_SH.text=elemento
    root.root.ids.km_DL.text=elemento

    root.root.ids.km_f.text=elemento
    pki_ahue=str(int(elemento)*1000)

    root.root.ids.progresiva_ahuellamiento.text=pki_ahue
    root.root.ids.odometro_f.text="000"
    root.root.ids.pki_huecos.text=pki_ahue
    root.root.ids.pki_observaciones.text=pki_ahue
    root.root.ids.pki_hundimiento.text=pki_ahue

    root.menu.dismiss()  

def menu_hm(root):

    HM_items = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']

    menu_HM_items = [
        {
            "text": hm_i,
            "font_size":60,
            "viewclass": "OneLineListItem",
            "text_color": get_color_from_hex("#FFFFFF"),
            "on_release": lambda x=hm_i: hm_valor(root,x),
        } for hm_i in HM_items
    ]
    root.menu = MDDropdownMenu(
        caller=root.screen.ids.hm_inv,
        background_color=get_color_from_hex("#000000"),
        items=menu_HM_items,
        width_mult=4)        

def hm_valor(root, text_item):
    
    elemento=text_item
    root.root.ids.hm_inv.text=elemento
    kilometro_ahue=root.root.ids.km_inv.text

    hectometro_ahue=root.root.ids.hm_inv.text
    pki_ahue=kilometro_ahue+str(int(hectometro_ahue)*100-100) if int(hectometro_ahue) > 1 else str(int(kilometro_ahue)*1000)

    root.root.ids.progresiva_ahuellamiento.text=pki_ahue
    root.root.ids.odometro_f.text=str(int(hectometro_ahue)*100-100) if int(hectometro_ahue) > 1 else "000"
    root.root.ids.pki_huecos.text=pki_ahue
    root.root.ids.pki_observaciones.text=pki_ahue
    root.root.ids.pki_hundimiento.text=pki_ahue

    root.menu.dismiss()  