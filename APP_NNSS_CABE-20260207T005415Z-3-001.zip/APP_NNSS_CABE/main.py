from kivy.lang import Builder
from kivy.metrics import sp,dp
from kivy.uix.anchorlayout import AnchorLayout
from kivy.properties import ObjectProperty, StringProperty, ListProperty,DictProperty
from kivy.core.window import Window
from kivy.utils import platform
from kivy.graphics.texture import Texture
from kivy.uix.camera import Camera
from kivy.config import Config
from kivy.base import ExceptionHandler, ExceptionManager

from kivymd.app import MDApp
from kivymd.theming import ThemableBehavior
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.list import OneLineIconListItem, MDList
from kivymd.uix.list import OneLineListItem
from kivymd.uix.card import MDCard
from kivymd.uix.gridlayout import MDGridLayout
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.screen import MDScreen
from kivymd.uix.screenmanager import ScreenManager

from kivymd.app import ThemeManager
from kivymd.uix.list import IRightBodyTouch, OneLineAvatarIconListItem
from kivymd.uix.selectioncontrol import MDCheckbox
from kivymd.uix.datatables import MDDataTable

import time
from kivy.clock import Clock
from kivymd.toast import toast
from plyer import gps

Config.set('graphics', 'resizable', False)
Config.set('graphics', 'width', '600')
Config.set('graphics', 'height', '900')
Config.set('graphics', 'fullscreen', '0')
Config.write()

class MyExceptionHandler(ExceptionHandler):
    def handle_exception(self, inst):
        # Maneja el error aquí
        toast("ERROR: " + str(inst))
        return ExceptionManager.PASS

class ContentNavigationDrawer(MDBoxLayout):
    screen_manager = ObjectProperty()
    nav_drawer = ObjectProperty()
    pass

class ItemDrawer(OneLineIconListItem):
    icon = StringProperty()
    text_color = ListProperty((0, 0, 0, 1))

class InventarioCalzadas2022(MDApp):

    data = DictProperty()

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._request_android_permissions()

    @staticmethod
    def is_android():
        return platform == 'android'

    def _request_android_permissions(self):
        """
        Requests CAMERA permission on Android.
        """
        if not self.is_android():
            return

    def on_location(self,**kwargs):
        try:
            lat=kwargs['lat']
            lon=kwargs['lon']
            alt=kwargs['altitude']
        except:
            print("no")

            lat ="0.0"
            lon ="0.0"
            alt ="0.0"
        
        self.root.ids.lat_label_DL.text=str(lat)
        self.root.ids.lon_label_DL.text=str(lon)

        self.root.ids.lat_label_sh.text=str(lat)
        self.root.ids.lon_label_sh.text=str(lon)

    def captura(self):
        from camara.camara_func import capture
        """Captura una imagen con OpenCV y la guarda en alta calidad"""
        global ubi_carpeta, Registro_Fotografico, session, n_scr, letra_n

        # Llamar a la nueva función capture() en camara_func.py
        capture(self, ubi_carpeta, Registro_Fotografico, session)

        if (n_scr == "scr 3") & (letra_n == "I"):
            self.root.ids.ahue_izquierdo.md_bg_color = [0, 1, 0, 1]

        elif (n_scr == "scr 3") & (letra_n == "D"):
            self.root.ids.ahue_derecho.md_bg_color = [0, 1, 0, 1]

        # Regresar a la pantalla anterior después de capturar la imagen
        self.root.ids.screen_manager.current = n_scr


    def build(self):
        self.icon = "mac_icono.jpg"
        self.theme_cls.theme_style = "Dark" # Establecer estilo oscuro para reducir el deslumbramiento
        self.theme_cls.primary_palette = "Gray" # Usar nuestra nueva paleta de colores personalizada
        self.screen = Builder.load_file("main.kv")
        return self.screen
    
    def on_start(self):
        from menus.obs_DL_func import on_start_DL
        # ExceptionManager.add_handler(MyExceptionHandler())
        on_start_DL(self)

    def cambiar_a_camara(self):
        global n_scr,letra_n

        letra_n = 0
        n_scr = self.root.ids.screen_manager.current
        print(n_scr)
        self.root.ids.screen_manager.current = 'scr 9'

    def cambiar_a_camara_ahu(self,letra_i):
        global n_scr,letra_n
        letra_n = letra_i
        n_scr = self.root.ids.screen_manager.current
        print(n_scr)
        self.root.ids.id_elemento.text="AHU_"+str(self.root.ids.ahue_label.text)+"_"+letra_i
        self.root.ids.screen_manager.current = 'scr 9'

#Creación de tablas

    def menu_rutas(self):
        from menus.rutas_func import menu_rutas
        menu_rutas(self)

    def acceder_bd(self):
        from utils.database_func import acceder

        global Inventario,Fisuras,Ahuellamiento,Hundimientos,\
            Huecos,Obstaculos,Parches,Peladuras,Msuelto,Pcocodrilos,Registro_Fotografico, session,ubi_carpeta,ubi
        try:
            Inventario,Fisuras,Ahuellamiento,Hundimientos,Huecos,\
                Obstaculos,Parches,Peladuras,Msuelto,Pcocodrilos,Registro_Fotografico, session,ubi_carpeta,ubi=\
                    acceder(self,subtramo=self.root.ids.ruta_label.text,\
                            kilometro=self.root.ids.km_bd.text)
            
            self.root.ids.screen_manager.current = 'scr 2'
        except:
            toast("ELEGIR SUBTRAMO O KM")
        try: 
            gps.configure(on_location=self.on_location)

            gps.start(minTime=1000,minDistance=0)

        except:
            toast("GPS NO ENCENDIDO")

    def menu_km(self):
        from menus.kmhm_func import menu_km
        menu_km(self)

    def menu_hm(self):
        from menus.kmhm_func import menu_hm
        menu_hm(self)

    def menu_elemento(self, caller):
        from menus.elemento_func import menu_elemento
        menu_elemento(self, caller)

    def menu_E_C(self):
        from menus.conservacion_func import menu_E_C
        menu_E_C(self)

    def menu_E_U(self):
        from menus.uso_func import menu_E_U
        menu_E_U(self)


    #Menu de Progresivas
    def menu_progresivas(self):
        from utils.S_Horizontal_func import menu_progresivas
        global Inventario, session
        menu_progresivas(self)

    def menu_carril(self, caller):
        from menus.carril_func import menu_carril
        menu_carril(self, caller)

    def menu_observaciones(self):
        from menus.observaciones_func import menu_observaciones
        menu_observaciones(self)

    def otras_obs(self):
        from menus.otras_observaciones import otras_obs
        otras_obs(self)

    #"storage/emulated/0/Documents/Pydroid3/plyer-master"

    #INVENTARIO
    def ingresar_inventario(self):
        from utils.inventario_func import ingresar_inventario
        global Inventario, session
        ingresar_inventario(self,Inventario=Inventario, session=session)

    def actualizar_inventario(self):
        from utils.inventario_func import actualizar_inventario
        global ubi
        actualizar_inventario(self,ubi=ubi)

    def limpiar_inventario(self):
        from utils.inventario_func import limpiar_inventario
        limpiar_inventario(self)

    #FISURAS
    def ingresar_fisuras(self):
        from utils.fisuras_func import ingresar_fisuras
        global Fisuras,session
        ingresar_fisuras(self,Fisuras=Fisuras, session=session)

    def actualizar_fisuras(self):
        from utils.fisuras_func import actualizar_fisuras
        global ubi
        actualizar_fisuras(self,ubi)

    def limpiar_fisuras(self):
        from utils.fisuras_func import limpiar_fisuras
        limpiar_fisuras(self)

    #AHUELLAMIENTO
    def ingresar_ahuellamiento(self):
        from utils.ahuellamiento_func import ingresar_ahuellamiento
        global Ahuellamiento, session
        ingresar_ahuellamiento(self,Ahuellamiento=Ahuellamiento, session=session)

    def actualizar_ahuellamiento(self):
        from utils.ahuellamiento_func import actualizar_ahuellamiento
        global ubi
        actualizar_ahuellamiento(self,ubi)

    def limpiar_ahuellamiento(self):
        from utils.ahuellamiento_func import limpiar_ahuellamiento
        limpiar_ahuellamiento(self)

    #HUNDIMIENTOS
    def ingresar_hundimientos(self):
        from utils.hundimientos_func import ingresar_hundimientos
        global Hundimientos, session
        ingresar_hundimientos(self,Hundimientos=Hundimientos, session=session)

    def actualizar_hundimientos(self):
        from utils.hundimientos_func import actualizar_hundimientos
        global ubi
        actualizar_hundimientos(self,ubi)

    def limpiar_hundimientos(self):
        from utils.hundimientos_func import limpiar_hundimientos
        limpiar_hundimientos(self)

    #HUECOS
    def ingresar_huecos(self):
        from utils.huecos_func import ingresar_huecos
        global Huecos, session
        ingresar_huecos(self,Huecos=Huecos, session=session)

    def actualizar_huecos(self):
        from utils.huecos_func import actualizar_huecos
        global ubi
        actualizar_huecos(self,ubi)

    def limpiar_huecos(self):
        from utils.huecos_func import limpiar_huecos
        limpiar_huecos(self)

    #OBSERVACION
    def ingresar_observacion(self):
        from utils.observaciones_func import ingresar_observacion
        global Obstaculos,Parches,Peladuras,Msuelto,Pcocodrilos, session
        ingresar_observacion(self,Obstaculos=Obstaculos,Parches=Parches,Peladuras=Peladuras,Msuelto=Msuelto,Pcocodrilos=Pcocodrilos, session=session)

    def actualizar_observaciones(self):
        from utils.observaciones_func import actualizar_observaciones
        global ubi
        actualizar_observaciones(self,ubi)

    def limpiar_observaciones(self):
        from utils.observaciones_func import limpiar_observaciones
        limpiar_observaciones(self)

    #SH
    def actualizar_SH_inv(self):
        from utils.S_Horizontal_func import actualizar_SH_inv

        actualizar_SH_inv(self)

    def añadir_SH_inv(self):
        from utils.S_Horizontal_func import añadir_SH_inv
        añadir_SH_inv(self)

    #Drenaje Longitudinal
    def menu_seccion_DL(self):
        from menus.seccion_DL_func import menu_seccion_DL
        menu_seccion_DL(self)

    def menu_tipo_DL(self):
        from menus.tipo_DL_func import menu_tipo_DL
        menu_tipo_DL(self)

    def menu_clasificacion_dl(self):
        from menus.clasificacion_DL_func import menu_clasificacion_dl
        menu_clasificacion_dl(self)

    def actualizar_DL_inv(self):
        from utils.D_Longitudinal_func import actualizar_DL_inv
        actualizar_DL_inv(self)

    def añadir_DL_inv(self):
        from utils.D_Longitudinal_func import añadir_DL_inv
        añadir_DL_inv(self)

    def menu_ids_DL(self):
        from utils.D_Longitudinal_func import menu_ids_DL
        menu_ids_DL(self)

    def get_selected_DL(self):
        from menus.obs_DL_func import get_selected_DL
        get_selected_DL(self)

    def show_table_DL(self):
        from utils.datatables import show_table_DL
        show_table_DL(self)

    def menu_obs_dl(self):
        self.root.ids.screen_manager.current = 'scr 13'

if __name__ == '__main__':    
    InventarioCalzadas2022().run()