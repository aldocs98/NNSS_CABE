import time
from kivymd.toast import toast
from kivy.clock import Clock
import os
from datetime import datetime
import sqlite3

def capture(root,ubi_carpeta,Registro_Fotografico, session):

    id_BD=root.root.ids.id_elemento.text
    carpeta = id_BD.split("_")[0]
    print(carpeta)
    def update_camera(dt):
        camera = root.root.ids.camera
        camera.play = True

    '''
    Function to capture the images and give them the names
    according to their captured time and date.
    '''
    if ubi_carpeta!=".":
        Clock.schedule_once(update_camera, 0.1)
        camera = root.root.ids.camera
        timestr = time.strftime("%Y%m%d_%H%M%S")

        try:
            ubi_subcarp = os.path.join(ubi_carpeta,carpeta)
            os.mkdir(ubi_subcarp)
        except:
            ubi_subcarp = os.path.join(ubi_carpeta,carpeta)

        try:
            ubi_id = os.path.join(ubi_subcarp,id_BD)
            os.mkdir(ubi_id)
        except:
            ubi_id = os.path.join(ubi_subcarp,id_BD)

        id_BD_str = id_BD+"_{}.png".format(timestr)
        camera.export_to_png(ubi_id+"/"+id_BD_str)
    
        root.root.ids.estado_foto.text="Foto guardada: "+id_BD

        #sqlite
        i_registro = Registro_Fotografico(Nombre=id_BD_str, \
                    Latitud=root.root.ids.lat_label_DL.text,\
                    Longitud=root.root.ids.lon_label_DL.text,\
                    Fecha_Obs=datetime.today())
        session.add(i_registro)
        session.commit()
        toast("FOTO GUARDADA: "+id_BD)
    
    elif ubi_carpeta==".":
        Clock.schedule_once(update_camera, 0.1)
        camera = root.root.ids.camera