# archivo database_func.py
import os
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from kivymd.toast import toast
from datetime import datetime

def acceder(root,subtramo,kilometro):
    
    today_i=datetime.today()
    fecha=str(today_i.day)+str(today_i.month)+str(today_i.year)+str(today_i.hour)+str(today_i.minute)+str(today_i.second)
    
    if (kilometro !="KILÓMETRO")&(subtramo!="RUTA"):

        try:
            root.root.ids.welcome_label.text=f'KM: {root.root.ids.km_bd.text}!'
            subtramo = subtramo.replace("-","")
            ubi_carpeta='BD_'+subtramo+'_'+kilometro+"_"+fecha
            os.mkdir(ubi_carpeta)

            ubi=os.path.join(ubi_carpeta,subtramo+'_'+kilometro+'.sqlite')
            
            engine = create_engine(str('sqlite:///'+ubi), echo=True)
            Base = declarative_base()

            #Tabla Inventario
            class Inventario(Base): # crear una sub clase User que hereda de la superclase Base
                __tablename__ = 'Registro_Inventario' # nombre de la tabla

                id = Column(Integer, primary_key=True) # campo id, llave primaria
                Subtramo = Column(String)
                PK_Inicial = Column(Integer) 
                PK_Final = Column(Integer)
                Latitud = Column(Float)
                Longitud = Column(Float)
                Berma_Izquierda = Column(Integer)
                Berma_Derecha = Column(Integer)
                Ancho = Column(Integer)
                KM= Column(Integer)
                HM= Column(Integer)
                Fecha= Column(DateTime)
                
                
                def __repr__(self):
                    return "<Inventario(Subtramo='%s',PK_Inicial='%s', PK_Final='%s',Latitud='%s',Longitud='%s',\
                            Berma_Izquierda='%s', Berma_Derecha='%s', Ancho='%s',KM='%s', HM='%s', Fecha='%s')>" \
                        % (self.st,self.pki,self.pkf, self.latitud, self.longitud, self.berma_i, self.berma_d,\
                            self.ancho, self.km, self.hm, self.fechaobs)

            Inventario.__table__ 

            class Fisuras(Base): # crear una sub clase User que hereda de la superclase Base
                __tablename__ = 'Registro_Fisuras' # nombre de la tabla

                id = Column(Integer, primary_key=True) # campo id, llave primaria
                Elemento = Column(String)
                PK_Inicial = Column(Integer)
                Lat = Column(Float)
                Long = Column(Float)
                Carril = Column(String) 
                Ancho = Column(Float)
                Longitud = Column(Float)
                Espesor = Column(Float)
                Área_de_Fisuras= Column(Float)
                Área_de_Fisuras_mayor_5= Column(Float)
                Observaciones= Column(String)
                KM= Column(Integer)
                HM= Column(Integer)
                Defecto= Column(String)
                Fecha_Obs= Column(DateTime)
                
                def __repr__(self):
                    return "<Fisuras(Elemento='%s',PK_Inicial='%s',Lat='%s',Long='%s', Carril='%s', \
                        Ancho='%s', Longitud='%s',Espesor='%s',Área_de_Fisuras='%s', Área_de_Fisuras_mayor_5='%s',\
                                Observaciones='%s', KM='%s', HM='%s', Defecto='%s', Fecha_Obs='%s')>" \
                        % (self.elem,self.pk, self.lat, self.long, self.carril, self.ancho, self.longitud,\
                            self.espesor, self.afm,self.afM, self.obs, self.km, self.hm, self.defecto, self.fechaobs)

            Fisuras.__table__ 
            
            #Tabla Hundimientos
            class Hundimientos(Base): # crear una sub clase User que hereda de la superclase Base
                __tablename__ = 'Registro_Hundimientos' # nombre de la tabla

                id = Column(Integer, primary_key=True) # campo id, llave primaria
                Elemento = Column(String)
                PK_Inicial = Column(Integer)
                Latitud = Column(Float)
                Longitud = Column(Float)
                Carril = Column(String)
                Ancho = Column(Float)
                Largo = Column(Float)
                Altura = Column(Float)
                Hundimiento= Column(Float)
                Observaciones= Column(String)
                KM= Column(Integer)
                HM= Column(Integer)
                Defecto= Column(String)
                Fecha_Obs= Column(DateTime)
                
                def __repr__(self):
                    return "<Hundimientos(Elemento='%s',PK_Inicial='%s',Latitud='%s',Longitud='%s', Carril='%s', Ancho='%s', Altura='%s',\
                        Hundimiento='%s',Observaciones='%s', KM='%s', HM='%s', Defecto='%s', Fecha_Obs='%s')>" \
                        % (self.elem,self.pk, self.latitud, self.longitud, self.carril, self.ancho, self.altura, self.Hundimiento,\
                        self.obs, self.km, self.hm, self.defecto, self.fechaobs)

            Hundimientos.__table__

            #Tabla Huecos
            class Huecos(Base): # crear una sub clase User que hereda de la superclase Base
                __tablename__ = 'Registro_Huecos' # nombre de la tabla

                id = Column(Integer, primary_key=True) # campo id, llave primaria
                Elemento = Column(String)
                PK_Inicial = Column(Integer)
                Latitud = Column(Float)
                Longitud = Column(Float)
                Carril = Column(String)
                Ancho = Column(Float)
                Largo = Column(Float)
                Altura = Column(Float)
                Hueco= Column(Float)
                Observaciones= Column(String)
                KM= Column(Integer)
                HM= Column(Integer)
                Defecto= Column(String)
                Fecha_Obs= Column(DateTime)
                
                def __repr__(self):
                    return "<Huecos(Elemento='%s',PK_Inicial='%s',Latitud='%s',Longitud='%s', Carril='%s', Ancho='%s', Altura='%s',\
                        Hueco='%s',Observaciones='%s', KM='%s', HM='%s', Defecto='%s', Fecha_Obs='%s')>" \
                        % (self.elem,self.pk, self.latitud, self.longitud, self.carril, self.ancho, self.altura, self.hueco,\
                        self.obs, self.km, self.hm, self.defecto, self.fechaobs)

            Huecos.__table__         
            
            #Tabla Ahuellamiento, cambiar el formato de pki y pkf por lista desplegable o km-hm
            class Ahuellamiento(Base): # crear una sub clase User que hereda de la superclase Base
                __tablename__ = 'Registro_Ahuellamiento' # nombre de la tabla

                id = Column(Integer, primary_key=True) # campo id, llave primaria
                Elemento = Column(String)
                PK_Inicial = Column(Integer)
                PK_Final = Column(Integer)
                Longitud=Column(Integer)
                Carril_I = Column(String)
                CI_H_Izquierda = Column(Integer)
                CI_H_Derecha = Column(Integer)
                CI_Observaciones= Column(String)
                Carril_D = Column(String)
                CD_H_Izquierda = Column(Integer)
                CD_H_Derecha = Column(Integer)
                CD_Observaciones= Column(String)
                KM= Column(Integer)
                HM= Column(Integer)
                Defecto= Column(String)
                Fecha_Obs= Column(DateTime)
                
                def __repr__(self):
                    return "<Ahuellamiento(Elemento='%s', PK_Inicial='%s', PK_Final='%s',\
                        Longitud='%s',Carril_I='%s', CI_H_Izquierda='%s', CI_H_Derecha='%s', CI_Observaciones='%s',\
                        Carril_D='%s', CD_H_Izquierda='%s', CD_H_Derecha='%s', CD_Observaciones='%s',\
                            KM='%s', HM='%s', Defecto='%s', Fecha_Obs='%s')>" \
                        % (self.elem,self.pki,self.pkf, self.longitud,  \
                            self.carril_I,self.CI_h_izquierdo,self.CI_h_derecho,self.CI_obs,\
                            self.carril_D,self.CD_h_izquierdo,self.CD_h_derecho,self.CD_obs,\
                            self.km, self.hm, self.defecto, self.fechaobs)

            Ahuellamiento.__table__   
            
            #Tabla Obstaculos
            class Obstaculos(Base): # crear una sub clase User que hereda de la superclase Base
                __tablename__ = 'Registro_Obstaculos' # nombre de la tabla

                id = Column(Integer, primary_key=True) # campo id, llave primaria
                Elemento = Column(String)
                PK_Inicial = Column(Integer)
                Latitud = Column(Float)
                Longitud = Column(Float) 
                Carril = Column(String)
                Ancho = Column(Float)
                Largo = Column(Float)
                Medida = Column(Float)
                Obstaculos= Column(String)
                KM= Column(Integer)
                HM= Column(Integer)
                Defecto= Column(String)
                Fecha_Obs= Column(DateTime)
                
                def __repr__(self):
                    
                    return "<Obstaculos(Elemento='%s',PK_Inicial='%s',Latitud='%s',Longitud='%s', Carril='%s', Ancho='%s',\
                            Medida='%s', Obstaculos='%s', KM='%s', HM='%s', Defecto='%s', Fecha_Obs='%s')>" \
                        % (self.elem, self.pk, self.latitud, self.longitud, self.carril, self.ancho, self.largo,\
                            self.med, self.obs, self.km, self.hm, self.defecto, self.fechaobs)

            Obstaculos.__table__
            
            #Tabla Parches
            class Parches(Base): # crear una sub clase User que hereda de la superclase Base
                __tablename__ = 'Registro_Parches' # nombre de la tabla

                id = Column(Integer, primary_key=True) # campo id, llave primaria
                Elemento = Column(String)
                PK_Inicial = Column(Integer)
                Latitud = Column(Float)
                Longitud = Column(Float) 
                Carril = Column(String)
                Ancho = Column(Float)
                Largo = Column(Float)
                Medida = Column(Float)
                Parches= Column(String)
                KM= Column(Integer)
                HM= Column(Integer)
                Defecto= Column(String)
                Fecha_Obs= Column(DateTime)
                
                def __repr__(self):
                    
                    return "<Parches(Elemento='%s',PK_Inicial='%s',Latitud='%s',Longitud='%s', Carril='%s', Ancho='%s',\
                            Medida='%s', Parches='%s', KM='%s', HM='%s', Defecto='%s', Fecha_Obs='%s')>" \
                        % (self.elem, self.pk, self.latitud, self.longitud, self.carril, self.ancho, self.largo,\
                            self.med, self.obs, self.km, self.hm, self.defecto, self.fechaobs)

            Parches.__table__
            
            #Tabla Peladuras
            class Peladuras(Base): # crear una sub clase User que hereda de la superclase Base
                __tablename__ = 'Registro_Peladuras' # nombre de la tabla

                id = Column(Integer, primary_key=True) # campo id, llave primaria
                Elemento = Column(String)
                PK_Inicial = Column(Integer)
                Latitud = Column(Float)
                Longitud = Column(Float) 
                Carril = Column(String)
                Ancho = Column(Float)
                Largo = Column(Float)
                Medida = Column(Float)
                Peladuras= Column(String)
                KM= Column(Integer)
                HM= Column(Integer)
                Defecto= Column(String)
                Fecha_Obs= Column(DateTime)
                
                def __repr__(self):
                    
                    return "<Peladuras(Elemento='%s',PK_Inicial='%s',Latitud='%s',Longitud='%s', Carril='%s', Ancho='%s',\
                            Medida='%s', Peladuras='%s', KM='%s', HM='%s', Defecto='%s', Fecha_Obs='%s')>" \
                        % (self.elem, self.pk, self.latitud, self.longitud, self.carril, self.ancho, self.largo,\
                            self.med, self.obs, self.km, self.hm, self.defecto, self.fechaobs)

            Peladuras.__table__

            #Tabla Msuelto
            class Msuelto(Base): # crear una sub clase User que hereda de la superclase Base
                __tablename__ = 'Registro_Msuelto' # nombre de la tabla

                id = Column(Integer, primary_key=True) # campo id, llave primaria
                Elemento = Column(String)
                PK_Inicial = Column(Integer)
                Latitud = Column(Float)
                Longitud = Column(Float) 
                Carril = Column(String)
                Ancho = Column(Float)
                Largo = Column(Float)
                Medida = Column(Float)
                Msuelto= Column(String)
                KM= Column(Integer)
                HM= Column(Integer)
                Defecto= Column(String)
                Fecha_Obs= Column(DateTime)
                
                def __repr__(self):
                    
                    return "<Msuelto(Elemento='%s',PK_Inicial='%s',Latitud='%s',Longitud='%s', Carril='%s', Ancho='%s',\
                            Medida='%s', Msuelto='%s', KM='%s', HM='%s', Defecto='%s', Fecha_Obs='%s')>" \
                        % (self.elem, self.pk, self.latitud, self.longitud, self.carril, self.ancho, self.largo,\
                            self.med, self.obs, self.km, self.hm, self.defecto, self.fechaobs)

            Msuelto.__table__

            #Tabla Pcocodrilos
            class Pcocodrilos(Base): # crear una sub clase User que hereda de la superclase Base
                __tablename__ = 'Registro_Pcocodrilos' # nombre de la tabla

                id = Column(Integer, primary_key=True) # campo id, llave primaria
                Elemento = Column(String)
                PK_Inicial = Column(Integer)
                Latitud = Column(Float)
                Longitud = Column(Float) 
                Carril = Column(String)
                Ancho = Column(Float)
                Largo = Column(Float)
                Medida = Column(Float)
                Pcocodrilos= Column(String)
                KM= Column(Integer)
                HM= Column(Integer)
                Defecto= Column(String)
                Fecha_Obs= Column(DateTime)
                
                def __repr__(self):
                    
                    return "<Pcocodrilos(Elemento='%s',PK_Inicial='%s',Latitud='%s',Longitud='%s', Carril='%s', Ancho='%s',\
                            Medida='%s', Pcocodrilos='%s', KM='%s', HM='%s', Defecto='%s', Fecha_Obs='%s')>" \
                        % (self.elem, self.pk, self.latitud, self.longitud, self.carril, self.ancho, self.largo,\
                            self.med, self.obs, self.km, self.hm, self.defecto, self.fechaobs)

            Pcocodrilos.__table__

            #Tabla Registro Fotografico
            class Registro_Fotografico(Base): # crear una sub clase User que hereda de la superclase Base
                __tablename__ = 'Registro_Fotografico' # nombre de la tabla

                id = Column(Integer, primary_key=True) # campo id, llave primaria
                Nombre = Column(String)
                Latitud = Column(String)
                Longitud = Column(String)
                Fecha_Obs= Column(DateTime)
                
                def __repr__(self):
                    
                    return "<Registro_Fotografico(Nombre='%s,Latitud='%s',Longitud='%s', Fecha_Obs='%s')>" \
                        % (self.nom, self.latitud, self.longitud, self.fechaobs)

            Registro_Fotografico.__table__

            #crear tablas
            Base.metadata.create_all(engine)

            #crear sesión
            Session = sessionmaker(bind=engine)
            session = Session() # conectarnos con la base de datos

            toast("SE CREO BASE DE DATOS")
            return Inventario,Fisuras,Ahuellamiento,Hundimientos,Huecos,Obstaculos,Parches,Peladuras,Msuelto,Pcocodrilos,Registro_Fotografico, session,ubi_carpeta,ubi
        except:
            toast("ERROR AL CREAR BASE DE DATOS") 