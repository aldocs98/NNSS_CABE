from datetime import datetime
import sqlite3
from kivymd.toast import toast

def ingresar_inventario(root,Inventario,session):

    subtramo_seleccionado=root.root.ids.ruta_label.text
    kilometro_seleccionado=0.0
    hectometro_seleccionado=0.0
    Berma_I=0.0
    Berma_D=0.0
    Ancho_C=0.0
    fecha_inv=datetime.today()
    pk=0.0
    lat=0.0
    lon=0.0

    #sqlite
    i_registro = Inventario(Subtramo=subtramo_seleccionado,\
        PK_Inicial=pk,PK_Final=pk+100,Latitud=float(lat), Longitud=float(lon),Berma_Izquierda=int(Berma_I),Berma_Derecha=int(Berma_D),\
            Ancho=int(Ancho_C),KM=int(kilometro_seleccionado),HM=int(hectometro_seleccionado),Fecha=fecha_inv)
    
    session.add(i_registro)

    #commit
    session.commit() # ejecuta los cambios y cargalos a la base de datos real

    root.root.ids.actualizar_inv.md_bg_color = [1, 0, 0, 1]
    root.root.ids.plus_inv.md_bg_color = [1, 0, 0, 1]

    root.root.ids.id_elemento.text="ICB_"+str(i_registro.id)
    root.root.ids.Inv_label.text=str(i_registro.id)
    toast("Se creó: "+"ICB_"+str(i_registro.id))

def actualizar_inventario(root,ubi):

    id_elemento = root.root.ids.Inv_label.text

    if id_elemento=="N":
        toast("NO HA CREADO ELEMENTO")
    else:
            
        subtramo_seleccionado = root.root.ids.ruta_label.text
        kilometro_seleccionado = root.root.ids.km_inv.text
        hectometro_seleccionado = root.root.ids.hm_inv.text
        Berma_I = root.root.ids.berma_izquierda.text
        Berma_D = root.root.ids.berma_derecha.text
        Ancho_C = root.root.ids.ancho_calzada.text
        fecha_inv = datetime.today()
        pk = int(kilometro_seleccionado) * 1000 + int(hectometro_seleccionado) * 100
        lat = root.root.ids.lat_label.text
        lon = root.root.ids.lon_label.text

        # Conectarse a la base de datos
        connection = sqlite3.connect(ubi)
        cursor = connection.cursor()

        # Ejecutar consulta UPDATE para actualizar el registro en la base de datos
        cursor.execute('''UPDATE Registro_Inventario SET Subtramo=?, PK_Inicial=?, PK_Final=?, Latitud=?, Longitud=?, Berma_Izquierda=?, Berma_Derecha=?, Ancho=?, KM=?, HM=?, Fecha=? WHERE id=?''', 
                    (subtramo_seleccionado, pk, pk+100, float(lat), float(lon), int(Berma_I), int(Berma_D), int(Ancho_C), int(kilometro_seleccionado), int(hectometro_seleccionado), fecha_inv, int(id_elemento)))

        # Guardar cambios en la base de datos
        connection.commit()

        # Cerrar la conexión con la base de datos
        connection.close()

        root.root.ids.actualizar_inv.md_bg_color = [0, 0, 0, 1]
        root.root.ids.plus_inv.md_bg_color = [1, 1, 0, 1]

        # Actualizar etiquetas o widgets según sea necesario
        root.root.ids.id_elemento.text = "ICB_" + str(id_elemento)
        root.root.ids.Inv_label.text="N"
        toast("Se actualizó: "+"ICB_"+str(id_elemento))

def limpiar_inventario(root):

    root.root.ids.berma_izquierda.text=""
    root.root.ids.berma_derecha.text=""
    root.root.ids.ancho_calzada.text=""