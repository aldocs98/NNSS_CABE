from datetime import datetime
from utils.kmh_func import km_hectometro
from kivymd.toast import toast
import sqlite3

def calcular_hundimiento(ancho,largo):
    
    hundimiento_calculado=float(ancho)*float(largo)
    
    return hundimiento_calculado
    
def ingresar_hundimientos(root,Hundimientos, session):
    
    #data ingresada
    
    fecha_h=datetime.today()
    pk_h=""
    ancho_h=0.0
    largo_h=0.0
    altura_h=0.0
    obs_h=""
    carril_hun=root.root.ids.carril_hun.text
    elemento_hun=root.root.ids.elemento_hun.text
    km_h, hectometro_h = 0.0,0.0
    hundimiento_h=0.0
    
    #defecto
    defecto_h=""

    lat=0.0
    lon=0.0

    #sqlite
    i_registro = Hundimientos(Elemento=elemento_hun,PK_Inicial=pk_h,Latitud=float(lat),Longitud=float(lon),Carril =carril_hun,\
                        Ancho=ancho_h,Largo=largo_h,Altura=altura_h,Hundimiento=hundimiento_h,\
                            Observaciones=obs_h,KM=km_h,HM=hectometro_h,\
                                Defecto=defecto_h,Fecha_Obs=fecha_h)
    
    session.add(i_registro)
    
    #commit
    session.commit() # ejecuta los cambios y cargalos a la base de datos real
    root.root.ids.Ingresando_Valores_hundimiento.text="Datos Ingresados"
    root.root.ids.id_elemento.text="HUN_"+str(i_registro.id)
    root.root.ids.hundimientos_label.text=str(i_registro.id)
    toast("Se creó: "+"HUN_"+str(i_registro.id))

def actualizar_hundimientos(root, ubi):

    id_elemento = root.root.ids.hundimientos_label.text
    
    if id_elemento=="N":
        toast("NO HA CREADO ELEMENTO")
    else:
        # Data ingresada
        fecha_h = datetime.today()
        pk_h = root.root.ids.pki_hundimiento.text
        ancho_h = root.root.ids.ancho_hundimiento.text
        largo_h = root.root.ids.largo_hundimiento.text
        altura_h = root.root.ids.altura_hundimiento.text
        obs_h = root.root.ids.observacion_hundimiento.text
        carril_hun = root.root.ids.carril_hun.text
        elemento_hun = root.root.ids.elemento_hun.text
        km_h, hectometro_h = km_hectometro(pk_h)
        hundimiento_h = calcular_hundimiento(ancho_h, largo_h)

        # Defecto
        defecto_h = "SI"

        lat = root.root.ids.lat_label.text
        lon = root.root.ids.lon_label.text

        # Conectarse a la base de datos
        connection = sqlite3.connect(ubi)
        cursor = connection.cursor()

        # Ejecutar consulta UPDATE para actualizar el registro en la base de datos
        cursor.execute('''UPDATE Registro_Hundimientos SET Elemento=?, PK_Inicial=?, Latitud=?, Longitud=?, Carril=?, Ancho=?, Largo=?, Altura=?, Hundimiento=?, Observaciones=?, KM=?, HM=?, Defecto=?, Fecha_Obs=? WHERE id=?''', 
                    (elemento_hun, pk_h, float(lat), float(lon), carril_hun, ancho_h, largo_h, altura_h, hundimiento_h, obs_h, km_h, hectometro_h, defecto_h, fecha_h, int(id_elemento)))

        # Guardar cambios en la base de datos
        connection.commit()

        # Cerrar la conexión con la base de datos
        connection.close()

        root.root.ids.Ingresando_Valores_hundimiento.text = "Datos Actualizados"
        root.root.ids.id_elemento.text = "HUN_" + str(id_elemento)
        root.root.ids.hundimientos_label.text="N"
        toast("Se actualizó: "+"HUN_"+str(id_elemento))

def limpiar_hundimientos(root):
    
    root.root.ids.Ingresando_Valores_hundimiento.text="Ingresando Datos..."
    
    root.root.ids.pki_hundimiento.text=""

    root.root.ids.ancho_hundimiento.text=""

    root.root.ids.largo_hundimiento.text=""

    root.root.ids.altura_hundimiento.text=""
    
    root.root.ids.observacion_hundimiento.text=""
