from datetime import datetime
from utils.kmh_func import km_hectometro
import sqlite3
from kivymd.toast import toast

def ingresar_fisuras(root,Fisuras,session):

    #sqlite
    i_registro = Fisuras(Elemento=root.root.ids.elemento_f.text,\
        PK_Inicial=int(0),Lat=float(0.0), Long=float(0.0),Carril=root.root.ids.carril_f.text,\
            Ancho=float(0.0),Longitud=float(0.0),Espesor=float(0.0),Área_de_Fisuras=0.0,\
            Área_de_Fisuras_mayor_5=0.0,Observaciones=root.root.ids.obs.text,KM=0,HM=0,Defecto="",Fecha_Obs=datetime.today())
    
    session.add(i_registro)
    
    #commit
    session.commit() # ejecuta los cambios y cargalos a la base de datos real
    
    root.root.ids.Ingresando_Valores.text="Datos Ingresados"
    root.root.ids.id_elemento.text="FIS_"+str(i_registro.id)
    root.root.ids.fisuras_label.text=str(i_registro.id)
    toast("Se creó: "+"FIS_"+str(i_registro.id))

def actualizar_fisuras(root,ubi):

    def area_fisura(espesor, ancho, longitud):

        if ((float(espesor) >= 2.5) and (float(espesor) <= 5)):
            afm = float(ancho) * float(longitud)
            afM = 0

        elif (float(espesor) > 5):
            afm = 0
            afM = float(ancho) * float(longitud)

        else:
            afm = 0
            afM = 0

        return afm, afM

    id_elemento = root.root.ids.fisuras_label.text

    if id_elemento=="N":
        toast("NO HA CREADO ELEMENTO")
    else:
        # Datos ingresados
        fecha = datetime.today()
        ancho = root.root.ids.ancho_f.text
        longitud = root.root.ids.longitud_f.text
        espesor = root.root.ids.espesor_f.text
        carril_f = root.root.ids.carril_f.text
        elemento_f = root.root.ids.elemento_f.text
        afm, afM = area_fisura(espesor, ancho, longitud)
        km = root.root.ids.km_f.text
        odometro = root.root.ids.odometro_f.text
        pk = km + odometro
        km, hectometro = km_hectometro(pk)
        defecto = "SI"

        obs = root.root.ids.obs.text

        lat = root.root.ids.lat_label.text
        lon = root.root.ids.lon_label.text

        # Conectarse a la base de datos
        connection = sqlite3.connect(ubi)
        cursor = connection.cursor()

        # Ejecutar consulta UPDATE para actualizar el registro en la base de datos
        cursor.execute('''UPDATE Registro_Fisuras SET Elemento=?, PK_Inicial=?, Lat=?, Long=?, Carril=?, Ancho=?, Longitud=?, Espesor=?, Área_de_Fisuras=?, Área_de_Fisuras_mayor_5=?, Observaciones=?, KM=?, HM=?, Defecto=?, Fecha_Obs=? WHERE id=?''', 
                    (elemento_f, int(pk), float(lat), float(lon), carril_f, float(ancho), float(longitud), float(espesor), afm, afM, obs, km, hectometro, defecto, fecha, int(id_elemento)))

        # Guardar cambios en la base de datos
        connection.commit()

        # Cerrar la conexión con la base de datos
        connection.close()

        # Actualizar etiquetas o widgets según sea necesario
        root.root.ids.Ingresando_Valores.text = "Datos actualizados"
        root.root.ids.id_elemento.text = "FIS_" + str(id_elemento)
        root.root.ids.fisuras_label.text="N"
        toast("Se actualizó: "+"FIS_"+str(id_elemento))

def limpiar_fisuras(root):
    
    root.root.ids.Ingresando_Valores.text="Ingresando Datos..."
    root.root.ids.ancho_f.text=""
    root.root.ids.longitud_f.text=""
    root.root.ids.espesor_f.text=""     
            