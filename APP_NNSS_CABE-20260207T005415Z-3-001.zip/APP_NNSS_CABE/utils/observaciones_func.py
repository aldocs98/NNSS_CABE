from datetime import datetime
from kivymd.toast import toast

# Diccionario para generar el ID con prefijo
dict_obs = {
    'Obstaculos': 'OBS',
    'Parches': 'PAR',
    'Peladuras': 'PEL',
    'Msuelto': 'MSUEL',
    'Pcocodrilos': 'PCO'
}

def calcular_area(ancho, largo):
    try:
        return float(ancho) * float(largo)
    except ValueError:
        return 0.0

def get_model_class(obs, Observaciones, Parches, Peladuras, Msuelto, Pcocodrilos):
    return {
        "Parches": Parches,
        "Peladuras": Peladuras,
        "Msuelto": Msuelto,
        "Pcocodrilos": Pcocodrilos,
        "Obstaculos": Observaciones
    }.get(obs, Observaciones)

def get_nombre_campo(obs):
    return {
        "Parches": "Parches",
        "Peladuras": "Peladuras",
        "Msuelto": "Msuelto",
        "Pcocodrilos": "Pcocodrilos",
        "Obstaculos": "Obstaculos"
    }.get(obs, "Observaciones")

def ingresar_observacion(root, Observaciones, Parches, Peladuras, Msuelto, Pcocodrilos, session):
    obs_sel = root.root.ids.otras_o.text
    fecha = datetime.today()

    try:
        pk = float(root.root.ids.pki_observaciones.text)
        ancho = float(root.root.ids.ancho_observaciones.text)
        largo = float(root.root.ids.largo_observaciones.text)
    except ValueError:
        toast("Error: Verifique que PK, Ancho y Largo sean numéricos.")
        return

    area = calcular_area(ancho, largo)
    try:
        from utils.kmh_func import km_hectometro
        km, hm = km_hectometro(pk)
    except Exception:
        km, hm = 0, 0

    carril = root.root.ids.carril_o.text
    elemento = root.root.ids.elemento_o.text
    descripcion = root.root.ids.observacion_observaciones.text
    lat = float(root.root.ids.lat_label.text or 0.0)
    lon = float(root.root.ids.lon_label.text or 0.0)
    defecto = "SI"

    Clase = get_model_class(obs_sel, Observaciones, Parches, Peladuras, Msuelto, Pcocodrilos)
    campo = get_nombre_campo(obs_sel)

    nuevo = Clase(
        Elemento=elemento,
        PK_Inicial=int(pk),
        Latitud=lat,
        Longitud=lon,
        Carril=carril,
        Ancho=ancho,
        Largo=largo,
        Medida=area,
        KM=km,
        HM=hm,
        Defecto=defecto,
        Fecha_Obs=fecha
    )
    setattr(nuevo, campo, descripcion)

    session.add(nuevo)
    session.commit()

    root.root.ids.Ingresando_Valores_observaciones.text = "Datos Ingresados"
    root.root.ids.id_elemento.text = dict_obs.get(obs_sel, "OBS") + "_" + str(nuevo.id)
    root.root.ids.observaciones_label.text = str(nuevo.id)
    toast(f"Se creó: {dict_obs.get(obs_sel, 'OBS')}_{nuevo.id}")

def actualizar_observaciones(root, ubi):
    import sqlite3

    obs_sel = root.root.ids.otras_o.text
    id_elem = root.root.ids.observaciones_label.text

    if id_elem == "N":
        toast("NO HA CREADO ELEMENTO")
        return

    try:
        pk = float(root.root.ids.pki_observaciones.text)
        ancho = float(root.root.ids.ancho_observaciones.text)
        largo = float(root.root.ids.largo_observaciones.text)
        area = calcular_area(ancho, largo)
        from utils.kmh_func import km_hectometro
        km, hm = km_hectometro(pk)
    except ValueError:
        toast("Valores numéricos inválidos.")
        return

    carril = root.root.ids.carril_o.text
    elemento = root.root.ids.elemento_o.text
    descripcion = root.root.ids.observacion_observaciones.text
    lat = float(root.root.ids.lat_label.text or 0.0)
    lon = float(root.root.ids.lon_label.text or 0.0)
    defecto = "SI"
    fecha = datetime.today()
    campo = get_nombre_campo(obs_sel)
    tabla = f"Registro_{obs_sel}" if obs_sel in dict_obs else "Registro_Observaciones"

    try:
        conn = sqlite3.connect(ubi)
        cur = conn.cursor()

        sql = f"""UPDATE {tabla} SET Elemento=?, PK_Inicial=?, Latitud=?, Longitud=?, Carril=?,
            Ancho=?, Largo=?, Medida=?, {campo}=?, KM=?, HM=?, Defecto=?, Fecha_Obs=? WHERE id=?"""
        
        cur.execute(sql, (
            elemento, int(pk), lat, lon, carril,
            ancho, largo, area, descripcion,
            int(km), int(hm), defecto, fecha, int(id_elem)
        ))
        conn.commit()
        conn.close()

        root.root.ids.Ingresando_Valores_observaciones.text = "Datos Actualizados"
        root.root.ids.id_elemento.text = dict_obs.get(obs_sel, "OBS") + "_" + str(id_elem)
        root.root.ids.observaciones_label.text = "N"
        toast(f"Se actualizó: {dict_obs.get(obs_sel, 'OBS')}_{id_elem}")
    except Exception as e:
        toast(f"Error al actualizar: {str(e)}")

def limpiar_observaciones(root):
    root.root.ids.Ingresando_Valores_observaciones.text = "Ingresando Datos..."
    root.root.ids.elemento_o.text = "Elemento"
    root.root.ids.carril_o.text = "Lado"
    root.root.ids.ancho_observaciones.text = ""
    root.root.ids.largo_observaciones.text = ""
    root.root.ids.observacion_observaciones.text = ""
