from datetime import datetime
import sqlite3
from kivymd.uix.menu import MDDropdownMenu

def menu_ids_DL(root):

    subtramo=root.root.ids.ruta_label.text
    km_text=root.root.ids.km_DL.text

    try:
        pro_nombre_db="BD_Drenaje_Longitudinal"
        con = sqlite3.connect(pro_nombre_db+".db")
        cursor = con.cursor()
        consulta_valor='SELECT _id FROM '+pro_nombre_db +" WHERE (RUTA=?) AND (KM=?)"
        cursor.execute(consulta_valor,[subtramo,km_text])

    except:
        print("Error")

    resultados = cursor.fetchall()

    lista_ids=[]
    for resultado in resultados:
        lista_ids.append(resultado[0])

    #CONVERSIÓN A STRING
    l_ids=[str(LP) for LP in lista_ids]
        
    menu_km_ids = [
        {
            "text": a_i,
            "font_size":60,
            "viewclass": "OneLineListItem",
            "on_release": lambda x=a_i: valor_progresivas(root,x),
        } for a_i in l_ids
    ]
    root.menu = MDDropdownMenu(
        caller=root.screen.ids.id_DL,
        items=menu_km_ids,
        width_mult=4,
    )

def valor_progresivas(root,text_item):

    id_select=str(text_item)
    root.root.ids.id_DL.text=id_select

    subtramo=root.root.ids.ruta_label.text
    km_text=root.root.ids.km_DL.text

    pro_nombre_db="BD_Drenaje_Longitudinal"
    con = sqlite3.connect(pro_nombre_db+".db")
    cursor = con.cursor()
    consulta_valor="SELECT *FROM BD_Drenaje_Longitudinal WHERE (RUTA = ?) AND (KM = ?) AND (_id = ?)"
    cursor.execute(consulta_valor,[subtramo,km_text,id_select])
        
    #índice de columnas
    data_elemento=cursor.fetchall()
    LISTA_ELEMENTO_PROGRESIVA=data_elemento[0]

    id_DL=str(LISTA_ELEMENTO_PROGRESIVA[0])
    root.root.ids.Prog_inicial_DL.text=str(LISTA_ELEMENTO_PROGRESIVA[3])
    root.root.ids.Prog_final_DL.text=str(LISTA_ELEMENTO_PROGRESIVA[6])
    root.root.ids.Estado_Conservacion_DL.text=str(LISTA_ELEMENTO_PROGRESIVA[15])
    root.root.ids.Estado_Uso_DL.text=str(LISTA_ELEMENTO_PROGRESIVA[16])
    root.root.ids.carril_DL.text=str(LISTA_ELEMENTO_PROGRESIVA[9])
    root.root.ids.clasificacion_DL.text=str(LISTA_ELEMENTO_PROGRESIVA[10])
    root.root.ids.tipo_DL.text=str(LISTA_ELEMENTO_PROGRESIVA[11])
    root.root.ids.seccion_DL.text=str(LISTA_ELEMENTO_PROGRESIVA[12])

    con.commit()
    con.close()

    root.menu.dismiss()

    root.root.ids.DL_Inv_label.text=id_DL

def actualizar_DL_inv(root):

    id_DL=root.root.ids.DL_Inv_label.text

    pro_nombre_db="BD_Drenaje_Longitudinal"
    con = sqlite3.connect(pro_nombre_db+".db")
    cursor = con.cursor()

    prog_inicial=root.root.ids.Prog_inicial_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET PROG_INICIAL = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[float(prog_inicial),id_DL])

    prog_final=root.root.ids.Prog_final_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET PROG_FINAL = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[float(prog_final),id_DL])

    estado_conservacion=root.root.ids.Estado_Conservacion_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET ESTADO_DE_CONSERVACION = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[estado_conservacion,id_DL])

    estado_uso=root.root.ids.Estado_Uso_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET ESTADO_DE_USO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[estado_uso,id_DL])

    carril_DL=root.root.ids.carril_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET LADO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[carril_DL,id_DL])

    clasi_DL=root.root.ids.clasificacion_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET CLASIFICACION = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[clasi_DL,id_DL])

    tipo_cuneta_DL=root.root.ids.tipo_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET TIPO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[tipo_cuneta_DL,id_DL])

    secc_cuneta_DL=root.root.ids.seccion_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET SECCION = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[int(secc_cuneta_DL),id_DL])

    obs_DL=root.root.ids.Observaciones_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET OBSERVACIONES = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[obs_DL,id_DL])

    con.commit()
    con.close()

    root.root.ids.id_elemento.text="06DL_"+id_DL

def añadir_DL_inv(root):

    fecha_inv=datetime.today()

    pro_nombre_db="BD_Drenaje_Longitudinal"
    con = sqlite3.connect(pro_nombre_db+".db")
    cursor = con.cursor()

    # Ejecutar la sentencia SQL para seleccionar los valores de la columna "mi_columna"
    cursor.execute("SELECT _id FROM "+pro_nombre_db)

    # Obtener los resultados de la consulta
    resultados = cursor.fetchall()

    # Pasar los valores a una lista
    valores_columna = [int(resultado[0]) for resultado in resultados]

    id_DL=str(max(valores_columna)+1)
    actualizacion_valor="INSERT INTO BD_Drenaje_Longitudinal (_id) VALUES (?)"
    cursor.execute(actualizacion_valor,[id_DL])

    subt=root.root.ids.ruta_label.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET RUTA = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[subt,id_DL])

    tramo=2
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET TRAMO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[tramo,id_DL])

    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET FECHA_DE_ALTA = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[fecha_inv,id_DL])

    periodo_nnss="2024-III"
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET PERIODO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[periodo_nnss,id_DL])

    prog_inicial=root.root.ids.Prog_inicial_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET PROG_INICIAL = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[float(prog_inicial),id_DL])

    prog_final=root.root.ids.Prog_final_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET PROG_FINAL = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[float(prog_final),id_DL])

    estado_conservacion=root.root.ids.Estado_Conservacion_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET ESTADO_DE_CONSERVACION = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[estado_conservacion,id_DL])

    estado_uso=root.root.ids.Estado_Uso_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET ESTADO_DE_USO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[estado_uso,id_DL])

    carril_DL=root.root.ids.carril_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET LADO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[carril_DL,id_DL])

    clasi_DL=root.root.ids.clasificacion_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET CLASIFICACION = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[clasi_DL,id_DL])

    tipo_cuneta_DL=root.root.ids.tipo_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET TIPO = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[tipo_cuneta_DL,id_DL])

    secc_cuneta_DL=root.root.ids.seccion_DL.text
    actualizacion_valor="UPDATE BD_Drenaje_Longitudinal SET SECCION = ? WHERE (_id = ?)"
    cursor.execute(actualizacion_valor,[int(secc_cuneta_DL),id_DL])

    con.commit()
    con.close()

    root.root.ids.id_elemento.text="06DL_"+id_DL