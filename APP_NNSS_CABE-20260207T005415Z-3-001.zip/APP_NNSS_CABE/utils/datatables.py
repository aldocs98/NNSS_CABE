import sqlite3
from kivymd.uix.datatables import MDDataTable
from kivy.metrics import dp

def show_table_DL(root):

    Ruta_A=root.root.ids.ruta_label.text
    KM_A=root.root.ids.km_DL.text

    conn = sqlite3.connect('BD_Drenaje_Longitudinal.db')
    cursor = conn.cursor()

    consulta_valor='SELECT _id, PROG_INICIAL, PROG_FINAL, LADO, CLASIFICACION, TIPO, SECCION FROM BD_Drenaje_Longitudinal WHERE (RUTA=?) AND (KM=?)'

    cursor.execute(consulta_valor,[Ruta_A,KM_A])
    data = cursor.fetchall()

    num_visible_rows = 10

    root.root.ids.card_content_DL.clear_widgets()

    root.table = MDDataTable(
        column_data=[
            ("ID", dp(14)),
            ("PKI", dp(16)),
            ("PKF", dp(16)),
            ("Lado", dp(18)),
            ("Clas", dp(18)),
            ("Tipo", dp(18)),
            ("Secc", dp(18))
        ],
        row_data=data,
        rows_num=num_visible_rows,
        use_pagination=True,
        check=False,
        elevation=2
    )

    root.root.ids.card_content_DL.add_widget(root.table)
